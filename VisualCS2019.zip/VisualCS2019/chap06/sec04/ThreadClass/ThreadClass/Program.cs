﻿using System;
using System.Threading;

namespace ThreadClass
{
    class Program
    {
        static void Main(string[] args)
        {
            var thread1 = new Thread(
                (s) => Console.WriteLine(s)
            );
            var thread2 = new Thread(
                (s) => Console.WriteLine(s)
            );
            thread1.Start("スレッド1を実行中。");
            thread2.Start("スレッド2を実行中。");
            Console.ReadKey();
        }
    }
}
