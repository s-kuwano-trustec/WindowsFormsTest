﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace ParallelInvoke
{
    class Program
    {
        static void Main(string[] args)
        {
            Parallel.Invoke(
                // メソッドの参照を登録
                Action,
                // ラムダ式で匿名メソッドとして登録
                () => {
                    Console.WriteLine("MethodB, Thread={0}",
                                       Thread.CurrentThread.ManagedThreadId);
                },
                // delegateステートメントで匿名メソッドとして登録
                delegate () {
                    Console.WriteLine("MethodC, Thread={0}",
                                      Thread.CurrentThread.ManagedThreadId);
                }
            );
            Console.ReadKey();
        }
        static void Action()
        {
            Console.WriteLine("MethodA, Thread={0}",
                              Thread.CurrentThread.ManagedThreadId);
        }
    }
}
