﻿using System;
using System.Threading.Tasks;

namespace ParallelFor
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 10; i++) Console.Write("{0} ", i);
            Console.WriteLine("serialで実行(順次処理)");

            Parallel.For(0, 10, (value) => Console.Write("{0} ", value));
            Console.WriteLine("parallelで実行(並行処理)");

            Console.ReadKey();
        }
    }
}
