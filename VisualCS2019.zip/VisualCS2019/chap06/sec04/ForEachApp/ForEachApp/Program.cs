﻿using System;
using System.Threading.Tasks;

namespace ForEachApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arrayData = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

            foreach (var a in arrayData)
            {
                Console.Write("{0} ", a);
            }
            Console.WriteLine("serialで順次処理");

            Parallel.ForEach(
                // 処理対象の配列
                arrayData,
                // 繰り返す処理
                (n) => Console.Write("{0} ", n)
            );
            Console.WriteLine("parallelで並行処理");
            Console.ReadKey();
        }
    }
}
