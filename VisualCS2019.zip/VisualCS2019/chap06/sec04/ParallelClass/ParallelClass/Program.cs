﻿using System;
using System.Threading.Tasks;

namespace ParallelClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Parallel.Invoke(
                () => Console.WriteLine("スレッド1を実行中。"),
                () => Console.WriteLine("スレッド2を実行中。"));
            Console.ReadKey();
        }
    }
}
