﻿using System;
using System.Threading;

namespace PassParam
{
    class Program
    {
        public static void Main()
        {
            // ClassTest型のインスタンスを生成
            ClassTest obj = new ClassTest();

            // TransferMethodメソッドに文字列を引数として渡す
            obj.Transfer("ABC");

            //メインの処理
            for (int i = 0; i < 100; i++)
            {
                // スレッドの切り替え
                Thread.Sleep(500);
                //画面表示
                Console.Write(" 123 ");
            }
            Console.ReadKey();
        }
    }

    public class ClassTest
    {
        // 引数を渡すためのフィールド
        private string textGet;

        // 呼び出し元から引数を受け取るための
        // パラメーターを実装したメソッド
        public void Transfer(string strPar)
        {
            // パラメーター値をフィールドにセット
            textGet = strPar;
            // ThreadMethod()を実行するスレッドを生成
            Thread threadTest =
                new Thread(new ThreadStart(ThreadMethod));
            threadTest.Start();
        }

        // スレッドで動作させるメソッド
        // Transfer()メソッドから渡された文字列を画面表示
        private void ThreadMethod()
        {
            for (int i = 0; i < 100; i++)
            {
                // スレッドの切り替え
                Thread.Sleep(500);
                //画面表示
                Console.Write(" {0} ", textGet);
            }
        }
    }
}
