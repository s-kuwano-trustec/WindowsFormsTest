﻿using System;
using System.Threading;

namespace ForAndBack
{
    class Program
    {
        static void Main()
        {
            // BackgroundTesttのインスタンスを生成
            BackgroundTest obj1 = new BackgroundTest(10);
            BackgroundTest obj2 = new BackgroundTest(10);

            // フォアグラウンドスレッドを生成
            Thread foregroundThread =
                new Thread(new ThreadStart(obj1.ThreadLoopMethod));
            foregroundThread.Name = "フォアグラウンドスレッド";

            // バックグラウンド用のスレッドを生成
            Thread backgroundThread =
                new Thread(new ThreadStart(obj2.ThreadLoopMethod));
            backgroundThread.Name = "バックグラウンドスレッド";

            // スレッドをバックグラウンドにする
            backgroundThread.IsBackground = true;

            foregroundThread.Start(); // フォアグラウンドスレッドの開始
            backgroundThread.Start(); // バックグラウンドスレッドの開始

            Console.ReadKey();
        }
    }

    class BackgroundTest
    {
        // 処理回数を保持するフィールド
        private int maxIteration;

        public BackgroundTest(int intIteration)
        {
            this.maxIteration = intIteration;
        }

        public void ThreadLoopMethod()
        {
            // スレッドの識別名を取得
            String threadName = Thread.CurrentThread.Name;

            for (int i = 0; i < maxIteration; i++)
            {
                // スレッド名と処理回数を表示
                Console.WriteLine("{0} count: {1}",
                                  threadName, i.ToString());
                // スレッドを一時停止
                Thread.Sleep(250);
            }
            Console.WriteLine(
                "{0} スレッドの処理が完了しました。", threadName);
        }
    }
}
