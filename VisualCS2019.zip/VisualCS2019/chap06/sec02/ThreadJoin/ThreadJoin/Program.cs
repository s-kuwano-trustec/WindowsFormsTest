﻿using System;
using System.Threading;

namespace ThreadJoin
{
    class Program
    {
        public static void Main()
        {
            Console.WriteLine("処理を開始しました。");

            //MethodTestメソッドを別のスレッドで実行
            Thread ThreadTest = new Thread(
                new ThreadStart(MethodTest));

            //コードを追加
            ThreadTest.IsBackground = true;

            //スレッドの開始
            ThreadTest.Start();
            ThreadTest.Join();
            Console.WriteLine("Enterキーを押してください。");

            //Enterキーが押されたことを確認
            Console.ReadLine();
        }

        // メソッド
        private static void MethodTest()
        {
            // ループ処理
            for (long i = 0; i < 5; i++)
             Console.WriteLine("処理中");

            // 処理が終了したことを通知
            Console.WriteLine("処理が完了しました。");
        }
    }
}
