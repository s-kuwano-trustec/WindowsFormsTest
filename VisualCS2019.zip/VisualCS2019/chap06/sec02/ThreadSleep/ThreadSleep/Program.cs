﻿using System;
using System.Threading;

namespace ThreadSleep
{
    class Program
    {
        public static void Main()
        {
            Thread threadA = new Thread(
              new ThreadStart(ThreadMethod)); // 

            threadA.Start(); // 

            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(500);
                Console.Write(" 123 ");
            }
            Console.ReadKey();
        }

        // 別スレッドで動作させるメソッド
        private static void ThreadMethod()
        {
            for (int i = 0; i < 100; i++)
            {
                Thread.Sleep(500);
                Console.Write(" ABC ");
            }
        }
    }
}
