﻿using System;
using System.Threading;

namespace Parameterized
{
    class Program
    {
        static void Main(string[] args)
        {
            // 静的メソッドThreadTest1()の参照を
            // ParameterizedThreadStart型のデリゲートとして
            // コンストラクターの引数に指定します。
            // これによってThreadTest1()を実行するスレッドが
            // 生成されます。
            Thread thread1 = new Thread(Program.ThreadTest1);

            // スレッドで実行するThreadTest1()メソッドに
            // 引数を渡してスレッドを開始します。
            thread1.Start(5000);

            // Programクラスのインスタンスを生成します。
            Program obj = new Program();

            // インスタンスメソッドThreadTest2()の参照を
            // デリゲートとしてコンストラクターの引数に指定し、
            // 新規のスレッドを生成します。
            Thread thread2 = new Thread(obj.ThreadTest2);

            // ThreadTest2()メソッドに
            // 引数を渡してスレッドを開始します。
            thread2.Start("スレッド実行中");

            Console.ReadKey();
        }

        // 1つ目のスレッドで実行する静的メソッド
        public static void ThreadTest1(object data)
        {
            Console.WriteLine(
                "スレッドに渡されたデータは、「{0}」です。",
                data
            );
        }

        // 2つ目のスレッドで実行するインスタンスメソッド
        public void ThreadTest2(object data)
        {
            Console.WriteLine(
                "スレッドに渡されたデータは、「{0}」です。",
                data
            );
        }
    }
}
