﻿using System;

namespace QueueUserWorkItem
{
    class Program
    {
        public static void Main()
        {
            // 引数を指定してClassTestのインスタンスを生成
            ClassTest obj = new ClassTest("プログラムの実行中です。");

            // デリゲートをスレッドプールのキューに追加する
            // メソッドで使用するオブジェクトobjも引数として渡す
            System.Threading.ThreadPool.QueueUserWorkItem(
                new System.Threading.WaitCallback(MethodTest),
                obj
            );

            // 3秒間、待機
            System.Threading.Thread.Sleep(3000);

            // Resultの値を表示
            Console.WriteLine(obj.Return);

            Console.ReadKey();

        }

        //スレッドで実行するメソッド
        private static void MethodTest(object parameter1)
        {
            // 渡されたデータをClassTest型に戻す
            ClassTest objParameter = (ClassTest)parameter1;

            // Returnプロパティに戻り値として返すデータを格納
            objParameter.Return = "引き続きプログラムの実行中です。";

            // 渡されたデータを表示
            Console.WriteLine(objParameter.Value);
        }
    }

    // データの受け渡しとデータの取得を行うためのクラス
    class ClassTest
    {
        // メソッドに渡すデータを保持するプロパティ
        public string Value { get; set; }
        // メソッドの処理結果を取得するためのプロパティ
        public string Return { get; set; }

        // コンストラクター
        public ClassTest(string str)
        {
            Value = str;
            Return = null;
        }
    }
}
