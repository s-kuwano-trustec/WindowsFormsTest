﻿using System;
using System.Threading;

namespace MonitorClass
{
    class Program
    {
        private static readonly object syncObj = new object();

        public static void Main()
        {
            //2つのスレッドを生成
            Thread thread1 = new Thread(
                                new ThreadStart(MethodTest1));
            thread1.Name = "Thread1";

            Thread thread2 = new Thread(
                                new ThreadStart(MethodTest2));
            thread2.Name = "Thread2";

            thread1.Start();
            thread2.Start();
            Console.ReadKey();
        }

        public static void MethodTest1()
        {
            Console.WriteLine("{0} : スレッドが生成されました。",
                              Thread.CurrentThread.Name);
            Console.WriteLine("{0} : 相互排他ロックを取得します。",
                              Thread.CurrentThread.Name);
            //ロックを取得
            Monitor.Enter(syncObj);

            lock (syncObj)
            {
                Console.WriteLine("{0} : Wait入ります。",
                                  Thread.CurrentThread.Name);
                // Wait()を実行
                Monitor.Wait(syncObj);

                Console.WriteLine("{0} : 時間がかかる処理を行っています。",
                                  Thread.CurrentThread.Name);
                Thread.Sleep(1000);

                // ロックを解除
                Monitor.Exit(syncObj);
                Console.WriteLine("{0} : 相互排他ロックを解除しました。",
                    Thread.CurrentThread.Name);
            }
            Console.WriteLine("{0} : スレッドを終了します。",
                Thread.CurrentThread.Name);
        }

        public static void MethodTest2()
        {
            Console.WriteLine("{0} : スレッドを生成しました。",
                Thread.CurrentThread.Name);

            lock (syncObj)
            {
                Console.WriteLine("{0} : Pulseを実行。",
                                  Thread.CurrentThread.Name);
                // Pulse()を実行
                Monitor.Pulse(syncObj);

                Console.WriteLine("{0} : 時間がかかる処理を行っています。",
                                  Thread.CurrentThread.Name);
                Thread.Sleep(2000);
            }
            Console.WriteLine("{0} : スレッドを終了します。",
               Thread.CurrentThread.Name);
        }
    }
}

