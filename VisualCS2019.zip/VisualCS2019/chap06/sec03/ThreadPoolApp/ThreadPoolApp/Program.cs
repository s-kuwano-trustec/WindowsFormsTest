﻿using System;
using System.Threading;

namespace ThreadPoolApp
{
    class Program
    {
        public static void Main()
        {
            Console.WriteLine("Main()メソッドのスレッドを開始します。");

            // メソッドをスレッドプールのキューに追加する
            ThreadPool.QueueUserWorkItem(
                new WaitCallback(MethodTest));

            // 画面表示
            Console.WriteLine("Enterキーで終了します。");

            // キーの入力待ち
            Console.ReadLine();
        }

        // スレッドで実行するメソッド
        private static void MethodTest(object obj)
        {
            // 一時、待機させる
            Thread.Sleep(5000);

            // 画面表示
            Console.WriteLine("別スレッドの処理が完了しました。");
        }
    }
}