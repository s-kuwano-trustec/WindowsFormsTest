﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataApp
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.tableTableAdapter.Fill(this.database1DataSet.Table);
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.tableBindingSource.EndEdit();
                this.tableTableAdapter.Update(this.database1DataSet.Table);
                MessageBox.Show("Update successful!");
            }
            catch
            {
                MessageBox.Show("Update failed");
            }
        }
    }
}
