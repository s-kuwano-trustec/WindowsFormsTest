﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataApp
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: このコード行はデータを 'database1DataSet1.Table' テーブルに読み込みます。必要に応じて移動、または削除をしてください。
            this.tableTableAdapter.Fill(this.database1DataSet1.Table);
            dataGridView1.DataSource = bindingSource1;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            var query = from rs in database1DataSet1.Table
                        where rs.Id > 1005
                        orderby rs.Name
                        select rs;
            bindingSource1.DataSource = query;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            bindingSource1.DataSource = database1DataSet1.Table;
        }
    }
}
