﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataApp
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
}
