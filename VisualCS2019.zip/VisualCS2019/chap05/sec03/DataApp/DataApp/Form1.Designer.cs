﻿namespace DataApp
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.Button6 = new System.Windows.Forms.Button();
            this.Button5 = new System.Windows.Forms.Button();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.Button4 = new System.Windows.Forms.Button();
            this.Button3 = new System.Windows.Forms.Button();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.Button2 = new System.Windows.Forms.Button();
            this.Button1 = new System.Windows.Forms.Button();
            this.ListBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Button6
            // 
            this.Button6.Location = new System.Drawing.Point(389, 325);
            this.Button6.Name = "Button6";
            this.Button6.Size = new System.Drawing.Size(118, 23);
            this.Button6.TabIndex = 24;
            this.Button6.Text = "データを消去";
            this.Button6.UseVisualStyleBackColor = true;
            this.Button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // Button5
            // 
            this.Button5.Location = new System.Drawing.Point(31, 325);
            this.Button5.Name = "Button5";
            this.Button5.Size = new System.Drawing.Size(118, 23);
            this.Button5.TabIndex = 23;
            this.Button5.Text = "データを追加";
            this.Button5.UseVisualStyleBackColor = true;
            this.Button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // TextBox2
            // 
            this.TextBox2.Location = new System.Drawing.Point(513, 53);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.Size = new System.Drawing.Size(100, 19);
            this.TextBox2.TabIndex = 22;
            // 
            // Button4
            // 
            this.Button4.Location = new System.Drawing.Point(389, 51);
            this.Button4.Name = "Button4";
            this.Button4.Size = new System.Drawing.Size(118, 23);
            this.Button4.TabIndex = 21;
            this.Button4.Text = "住所を指定して検索";
            this.Button4.UseVisualStyleBackColor = true;
            this.Button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // Button3
            // 
            this.Button3.Location = new System.Drawing.Point(31, 51);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(118, 23);
            this.Button3.TabIndex = 20;
            this.Button3.Text = "表示をクリア";
            this.Button3.UseVisualStyleBackColor = true;
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // TextBox1
            // 
            this.TextBox1.Location = new System.Drawing.Point(513, 15);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.Size = new System.Drawing.Size(100, 19);
            this.TextBox1.TabIndex = 19;
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(389, 13);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(118, 23);
            this.Button2.TabIndex = 18;
            this.Button2.Text = "Idを指定して抽出";
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Button1
            // 
            this.Button1.Location = new System.Drawing.Point(31, 13);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(118, 23);
            this.Button1.TabIndex = 17;
            this.Button1.Text = "全件表示";
            this.Button1.UseVisualStyleBackColor = true;
            this.Button1.Click += new System.EventHandler(this.Button1_Click_1);
            // 
            // ListBox1
            // 
            this.ListBox1.FormattingEnabled = true;
            this.ListBox1.ItemHeight = 12;
            this.ListBox1.Location = new System.Drawing.Point(31, 89);
            this.ListBox1.Name = "ListBox1";
            this.ListBox1.Size = new System.Drawing.Size(582, 220);
            this.ListBox1.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::DataApp.Properties.Resources.bgimg;
            this.ClientSize = new System.Drawing.Size(644, 360);
            this.Controls.Add(this.Button6);
            this.Controls.Add(this.Button5);
            this.Controls.Add(this.TextBox2);
            this.Controls.Add(this.Button4);
            this.Controls.Add(this.Button3);
            this.Controls.Add(this.TextBox1);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.Button1);
            this.Controls.Add(this.ListBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.Button Button6;
        internal System.Windows.Forms.Button Button5;
        internal System.Windows.Forms.TextBox TextBox2;
        internal System.Windows.Forms.Button Button4;
        internal System.Windows.Forms.Button Button3;
        internal System.Windows.Forms.TextBox TextBox1;
        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.Button Button1;
        internal System.Windows.Forms.ListBox ListBox1;
    }
}

