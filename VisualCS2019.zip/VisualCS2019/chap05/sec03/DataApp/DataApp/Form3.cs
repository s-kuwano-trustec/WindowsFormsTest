﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DataApp
{
    public partial class Form3 : Form
    {
        private SqlConnection cn = new SqlConnection();
        private SqlCommand cmd = new SqlCommand();
        private SqlDataReader rd;

        public Form3()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            cn.ConnectionString =
                @"Data Source=(LocalDB)\MSSQLLocalDB;" +
                @"AttachDbFilename=|DataDirectory|\Database1.mdf;" +
                "Integrated Security=True;" +
                "Connect Timeout=30";
            cn.Open();

            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "DELETE FROM [dbo].[Table]" +
                              "WHERE Id='" + TextBox1.Text + "'";

            rd = cmd.ExecuteReader();
            rd.Close();
            cn.Close();
            this.Close();
        }
    }
}
