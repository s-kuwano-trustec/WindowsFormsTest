﻿using System;
using System.Windows.Forms;

namespace NextBirthday
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int intBirthday;
            label2.Text = "選択した日付" + dateTimePicker1.Value.Date.ToString("yyyy/MM/dd");
            intBirthday = dateTimePicker1.Value.Subtract(DateTime.Today).Days;
            label3.Text = "本日から次の誕生日まであと" + intBirthday.ToString() + "日";
        }
    }
}
