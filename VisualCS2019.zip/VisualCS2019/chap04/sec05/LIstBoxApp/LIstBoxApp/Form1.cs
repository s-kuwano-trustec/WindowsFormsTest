﻿using System;
using System.Windows.Forms;

namespace LIstBoxApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
                MessageBox.Show("項目が未選択です。", "エラー");
            else
                MessageBox.Show(listBox1.SelectedItem.ToString(),
                    "明日は忘れずに");
        }
    }
}
