﻿using System;
using System.Windows.Forms;

namespace CheckBoxApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            int check1, check2, check3, total;
            check1 = 0;
            check2 = 0;
            check3 = 0;

            if (checkBox1.Checked)
                check1 = 500;
            if (checkBox2.Checked)
                check2 = 600;
            if (checkBox3.Checked)
                check3 = 700;

            total = check1 + check2 + check3;
            MessageBox.Show("合計金額は" + total + "円です。", "計算結果");
        }
    }
}
