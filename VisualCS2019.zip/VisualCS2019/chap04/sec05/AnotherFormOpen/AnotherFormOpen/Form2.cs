﻿using System.Windows.Forms;

namespace AnotherFormOpen
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }
    }
}
