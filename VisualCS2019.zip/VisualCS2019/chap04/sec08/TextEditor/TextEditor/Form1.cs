﻿using System;
using System.Windows.Forms;
using System.IO;

namespace TextEditor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            string saveFileName;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                saveFileName = saveFileDialog1.FileName;
            }
            else
            {
                return;
            }

            StreamWriter textFile =
                new StreamWriter(
                    new FileStream(saveFileName, FileMode.Create)
                );
            textFile.Write(textBox1.Text);
            textFile.Close();
        }

        private void ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            string openFileName;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                openFileName = openFileDialog1.FileName;
            }
            else
            {
                return;
            }

            textBox1.Clear();
            StreamReader textFile = new StreamReader(openFileName);
            textBox1.Text = textFile.ReadToEnd();
            textFile.Close();
        }

        private void ToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
