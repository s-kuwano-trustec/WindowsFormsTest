﻿using System;
using System.Windows.Forms;

namespace DateTimeApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            DateTime dat = DateTime.Now;
            label1.Text = dat.ToLongDateString();
        }

        private void ToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            DateTime dat = DateTime.Now;
            label1.Text = dat.ToShortTimeString();
        }

        private void ToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
