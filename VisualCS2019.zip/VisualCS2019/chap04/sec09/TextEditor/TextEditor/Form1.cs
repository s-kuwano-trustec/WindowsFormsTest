﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Printing;
using System.Drawing;


namespace TextEditor
{
    public partial class Form1 : Form
    {
        private string strPrint;
        private PageSettings pageSetting = new PageSettings();

        public Form1()
        {
            InitializeComponent();
        }

        private void ToolStripMenuItem6_Click(object sender, EventArgs e)
        {
            try
            {
                printDocument1.DefaultPageSettings = pageSetting;
                strPrint = textBox1.Text;
                printDialog1.Document = printDocument1;

                if (printDialog1.ShowDialog() == DialogResult.OK)
                {
                    printDocument1.Print();
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "エラー");
            }
        }

        private void PrintDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font Fontsize = new Font("MS UI Gothic", 11);
            int intNumberChars;
            int intNumberLines;
            string strPrintString;
            StringFormat strFormat = new StringFormat();

            RectangleF rectSquare =
                new RectangleF(e.MarginBounds.Left,
                              e.MarginBounds.Top,
                              e.MarginBounds.Width,
                              e.MarginBounds.Height
                              );

            SizeF SquareSize =
                new SizeF(e.MarginBounds.Width,
                          e.MarginBounds.Height -
                              Fontsize.GetHeight(e.Graphics)
                          );

            e.Graphics.MeasureString(strPrint,
                                     Fontsize,
                                     SquareSize,
                                     strFormat,
                                     out intNumberChars,
                                     out intNumberLines
                                     );

            strPrintString = strPrint.Substring(
                                        0, intNumberChars
                                      );

            e.Graphics.DrawString(strPrintString,
                                  Fontsize,
                                  Brushes.Black,
                                  rectSquare,
                                  strFormat
                                  );

            if (intNumberChars < strPrint.Length)
            {
                strPrint = strPrint.Substring(intNumberChars);
                e.HasMorePages = true;
            }
            else
            {
                e.HasMorePages = false;
                strPrint = textBox1.Text;
            }
        }

        private void ToolStripMenuItem11_Click(object sender, EventArgs e)
        {
            string FaileName;
            StreamReader textFaile;

            if (
                openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FaileName = openFileDialog1.FileName;
            }
            else
            {
                return;
            }

            textBox1.Clear();
            textFaile = new StreamReader(FaileName);
            textBox1.Text = textFaile.ReadToEnd();
            textFaile.Close();
        }

        private void ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            string strFileName;

            if (
                saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                strFileName = saveFileDialog1.FileName;
            }
            else
            {
                return;
            }

            StreamWriter textFile = new StreamWriter(
                new FileStream(strFileName, FileMode.Create));
            textFile.Write(textBox1.Text);
            textFile.Close();
        }

        private void ToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ToolStripMenuItem5_Click(object sender, EventArgs e)
        {
            // PrintDocumentオブジェクトにページ設定を登録
            printDocument1.DefaultPageSettings = pageSetting;
            // テキストボックスの文字列を取得
            strPrint = textBox1.Text;
            // PrintPreviewDialogオブジェクトに
            // PrintDocumentオブジェクトを登録
            printPreviewDialog1.Document = printDocument1;
            // ダイアログを表示
            printPreviewDialog1.ShowDialog();
        }

        private void ToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            // PageSetupDialogオブジェクトにページ設定を登録
            pageSetupDialog1.PageSettings = pageSetting;
            // ダイアログを表示
            pageSetupDialog1.ShowDialog();
        }
    }
}
