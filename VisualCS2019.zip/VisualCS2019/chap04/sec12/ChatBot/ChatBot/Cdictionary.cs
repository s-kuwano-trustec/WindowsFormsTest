﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ChatBot
{
    class Cdictionary
    {
        // 応答用に加工したランダム辞書の各1行を保持するリスト
        public List<string> Random = new List<string>();
        // パターン辞書から生成したParseItemオブジェクトを保持するリスト
        public List<ParseItem> Pattern = new List<ParseItem>();

        // コンストラクター
        public Cdictionary()
        {
            // ----- ランダム辞書の用意 -----'
            // ランダム辞書ファイルをオープンし、各行を要素として配列に格納
            string[] r_lines = File.ReadAllLines(
                @"dics\random.txt",
                System.Text.Encoding.UTF8
                );

            // ランダム辞書の各1行を応答用に加工してリストに追加する
            foreach (string line in r_lines)
            {
                string str = line.Replace("\n", ""); // 末尾の改行文字を取り除く
                if (line != "")                       // 空文字でなければリストRandomに追加
                {
                    this.Random.Add(str);
                }
            }

            //----- パターン辞書の用意 -----'
            // パターン辞書ファイルをオープンし、各行を要素として配列に格納
            string[] p_lines = File.ReadAllLines(
                @"dics\pattern.txt",
                System.Text.Encoding.UTF8
                );

            // 応答用に加工したパターン辞書の各1行を保持するリスト
            List<string> new_lines = new List<string>();
            // ランダム辞書の各1行を応答用に加工してリストに追加する
            foreach (string line in p_lines)
            {
                string str = line.Replace("\n", ""); // 末尾の改行文字を取り除く
                if (line != "")                      // 空文字でなければリストに追加
                {
                    new_lines.Add(str);
                }
            }

            /*  パターン辞書の各行をタブで切り分ける
             *  vb_prs(0)  正規表現のパターン
             * vb_prs(1)  応答メッセージ群
             * ParseItemオブジェクトを生成してリストPatternに追加
             */
            foreach (string line in new_lines)
            {
                string[] c_prs = line.Split(new Char[] { '\t' });
                this.Pattern.Add(
                    new ParseItem(c_prs[0], c_prs[1])
                    );
            }
        }
    }
}
