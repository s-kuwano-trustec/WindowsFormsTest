﻿using System;
using System.Collections.Generic;

namespace ChatBot
{
    class PatternResponder : Responder
    {
        /*
         * パターンに反応するためのサブクラス
         * */

        public PatternResponder(string name, Cdictionary dic) : base(name, dic)
        {
            /* サブクラスのコンストラクター
             */ 
        }

        public override string Response(string input, int mood)
        {
            /* Response()メソッドをオーバーライド
      　     * ランダム応答用のメッセージを作成して返す
             * input   ユーザーが入力した文字列
             * 戻り値  パターン辞書から抽出した応答文字列
             *         パターンマッチしない場合はランダム辞書から抽出した応答文字列
             */

            // 応答フレーズを保持する変数を初期化
            string resp = "";
            // VB_Dictionary.PatternプロパティでParseItemオブジェクトを1つずつ取り出す
            foreach (ParseItem c_item in Cdictionary.Pattern)
            {
                // ParseItemO.Match()でインプット文字列に
                // パターングループをマッチングさせる
                string mtc = c_item.Match(input);
                // マッチした場合は機嫌値moodを引数にしてChoice()を実行、
                // 戻り値の応答文字列、またはNothingを取得
                if (String.IsNullOrEmpty(mtc) == false)
                {
                    resp = c_item.Choice(mood);
                    // Choice()の戻り値がnullでない場合は
                    // 応答例の中の%match%をインプットされた文字列内の
                    // マッチした文字列に置き換える
                    if (resp != null)
                        return resp.Replace("%match%", mtc);
                }
            }

            // パターンマッチしない場合はランダム辞書から返す
            // システム起動後のミリ秒単位の経過時間を取得
            int seed = Environment.TickCount;
            // シード値を引数にしてRandomをインスタンス化
            Random rdm = new Random(seed);
            // ランダム辞書を保持するリスト
            List<string> c_random = new List<string>();
            // VBDictionaryのRandomプロパティの応答メッセージをリストに代入
            c_random = this.Cdictionary.Random;
            // リストから応答メッセージをランダムに抽出して返す
            return c_random[rdm.Next(0, c_random.Count)];
        }
    }
}
