﻿namespace ChatBot
{
    class RepeatResponder : Responder
    {
        public RepeatResponder(string name, Cdictionary dic) : base(name, dic)
        {
            /* サブクラスのコンストラクター
             */
        }

        public override string Response(string input, int mood)
        {
            /* Response()メソッドをオーバーライド
             * オウム返しのメッセージを作成して返す
             * 
             * input ：ユーザーがインプットした文字列
             */ 
           return string.Format("{0}ってなに？", input);
        }
    }
}
