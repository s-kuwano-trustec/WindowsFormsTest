﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ChatBot
{
    class ParseItem
    {
        // マッチしたパターン辞書の応答フレーズの
        // グループを参照/設定するプロパティ
        public string Pattern { get; set; }

        // 機嫌変動値を参照/設定するプロパティ
        public int Modify { get; set; }

        // パターン辞書がマッチした場合に、必要機嫌値と
        // 応答メッセージのDictionaryとして保持するリストのプロパティ
        public List<Dictionary<string, string>> _phrases =
            new List<Dictionary<string, string>>();
        public List<Dictionary<string, string>> Phrases
        {
            get { return _phrases; }
            set { _phrases = value; }
        }

        public ParseItem(string pattern, string phrases)
        {
            /* コンストラクター
             * 
             * pattern ：機嫌変動値##マッチさせるパターンのグループ
             * phrases ：応答フレーズのグループ
             *
             */

            // 正規表現のパターンを保持する変数
            string SEPARATOR = @"^((-?\d+)##)?(.*)$";

            /*----- パターンマッチさせる部分の処理 -----'
             * 「機嫌変動値##マッチさせるパターンのグループ」にSEPARATORを
             * パターンマッチさせ、機嫌変動値とパターングループに分解された
             * MatchCollectionオブジェクトを戻り値として取得
             */
            Regex rgx = new Regex(SEPARATOR);
            MatchCollection m = rgx.Matches(pattern);

            // MatchCollectionから先頭のMatchオブジェクトを取り出す
            Match mach = m[0];

            // 機嫌変動値のプロパティの値を0にする
            this.Modify = 0;

            // マッチ結果の整数の部分(インデックス2)が空でなければ
            // 機嫌変動値のプロパティの値を更新する
            if (string.IsNullOrEmpty(mach.Groups[2].Value) != true)

            {
                this.Modify = Convert.ToInt32(mach.Groups[2].Value);
            }

            // マッチした場合はマッチしたパターンのグループ(インデックス3)が
            // Patternプロパティに代入される。マッチしない場合は空文字が代入される
            this.Pattern = mach.Groups[3].Value;

            /*----- 応答部分の処理 -----'
             * 引数で渡された応答例のグループを' | 'を境に分割し、
             * 個々の要素に対してSEPARATORをパターンマッチさせる
             * dic("need")  : 応答フレーズの必要機嫌値
             * dic("phrase"): 応答フレーズ */

            foreach (string phrase in phrases.Split(new Char[] { '|' }))
            {
                // ハッシュテーブルを用意
                var dic = new Dictionary<string, string>();

                // 応答メッセージグループの個々のメッセージに対してSEPARATORを
                // パターンマッチさせ、必要機嫌値と応答フレーズに分解された
                // MatchCollectionオブジェクトを戻り値として取得
                MatchCollection m2 = rgx.Matches(phrase);

                // MatchCollectionから先頭のMatchオブジェクトを取り出す
                Match mach2 = m2[0];

                // "need"キーの値を0で初期化
                dic["need"] = "0";

                // mach.Groups(2)に値(必要機嫌値(整数))が存在すれば"need"キーの値としてセット
                if (string.IsNullOrEmpty(mach2.Groups[2].Value) != true)
                {
                    dic["need"] = Convert.ToString(mach2.Groups[2].Value);
                }
                // "phrase"キーの値をmach.Groups(3)(応答フレーズ)にする
                dic["phrase"] = mach2.Groups[3].Value;
                // 作成したDictionaryをPhrasesプロパティ(リスト)に追加
                this.Phrases.Add(dic);
            }
        }

        public string Match(string str)
        {
            /* インプット文字列にPatternプロパティ(各行ごとの正規表現のパターングループ)を
             * パターンマッチさせる
             *
             * str   ：ユーザーが入力した文字列
             * 戻り値：マッチングした応答メッセージ群
             *         マッチングしない場合は空文字を返す
             */

            // マッチした正規表現のパターングループをRegexオブジェクトに変換する
            Regex rgx = new Regex(this.Pattern);
            // インプット文字列に正規表現のパターングループをマッチさせた結果を返す
            Match mtc = rgx.Match(str);
            return mtc.Value;
        }

        public string Choice(int mood)
        {
            /* mood ：現在の機嫌値
             *
             * 応答フレーズ群からチョイスした応答フレーズをランダムに抽出して返す
             */

            // 応答フレーズを保持するリスト
            var choices = new List<String>();

            // Phrasesプロパティが参照するリストの要素（Dictionary）をdicに取り出す
            foreach (Dictionary<string, string> dic in this.Phrases)
            {
                // Suitable()を呼び出し、結果がTrueであれば
                // リストchoicesに"phrase"キーの応答フレーズを追加
                if (Suitable(
                    //"need"キーで必要機嫌値を取り出す
                    Convert.ToInt32(dic["need"]),
                    // パラメーターmoodで取得した現在の機嫌値
                    mood
                    )
                ){
                    // 結果がTrueであればリストchoicesに
                    // "phrase"キーの応答フレーズを追加
                    choices.Add(dic["phrase"]);
                }
            }
            // choicesリストが空であればnullを返す
            if (choices.Count == 0)
                return null;
            else
            {
                // choicesリストが空でなければシステム起動後のミリ秒単位の経過時間を取得
                int seed = Environment.TickCount;
                // シード値を引数にしてRandomをインスタンス化
                Random rnd = new Random(seed);
                // 応答フレーズをランダムに抽出して返す
                return choices[rnd.Next(0, choices.Count)];
            }
        }

        public bool Suitable(int need, int mood)
        {
            /*
             * need ：必要機嫌値
             * mood ：現在の機嫌値
             */

            if (need == 0)
                // 必要機嫌値が0であればTrueを返す
                return true;
            else if (need > 0)
                // 必要機嫌値がプラスの場合は、機嫌値が必要機嫌値を
                // 超えていればtrue、そうでなければfalseを返す
                return (mood > need);
            else
                // 応答例の数値がマイナスの場合は、機嫌値が必要機嫌値を
                // 下回っていればtrue、そうでなければfFalseを返す
                return (mood < need);
        }
    }
}
