﻿using System;

namespace ChatBot
{
    class Cchan
    {
        private string _name;                   // オブジェクト名を保持
        private Cdictionary _dictionary;        // Cdictionaryを保持
        private CchanEmotion _emotion;          // CchanEmotionを保持
        private RandomResponder _res_random;    // RandomResponderを保持
        private RepeatResponder _res_repeat;    // RepeatResponderを保持
        private PatternResponder _res_pattern;  // PatternResponderを保持
        private Responder _responder;           // Responder型のフィールド

        public string Name                      // _nameのプロパティ
        {
            get { return _name; }
            set { _name = value; }
        }

        public CchanEmotion Emotion             // _emotionのプロパティ
        {
            get { return _emotion; }
            set { _emotion = value; }
        }


        // コンストラクター
        public Cchan(string name)
        {
            this._name = name;
            // Cdictionaryをインスタンス化
            this._dictionary = new Cdictionary();
            // CchanEmotionをインスタンス化
            this._emotion = new CchanEmotion(_dictionary);
            // RepeatResponderをインスタンス化
            this._res_repeat = new RepeatResponder("Repeat", _dictionary);
            // RandomResponderをインスタンス化
            this._res_random = new RandomResponder("Random", _dictionary);
            // PatternResponderをインスタンス化
            this._res_pattern = new PatternResponder("Pattern", _dictionary);
        }

        // 応答メッセージを返すメソッド
        public string Dialogue(string input)
        {
            this._emotion.Update(input);

            Random rnd = new Random();      // Randomのインスタンス化
            int num = rnd.Next(0, 10); 　　 // 0～9の範囲の値をランダムに生成

            if (num < 6)                    // 0～5ならPatternResponderをチョイス
                _responder = _res_pattern;
            else if (num < 9)             　// 6～8ならRandomResponderをチョイス
                _responder = _res_random;
            else                            // それ以外はRepeatResponderをチョイス
                _responder = _res_repeat;

            // チョイスしたオブジェクトのResponse()メソッドを実行し
            // 応答メッセージを戻り値として返す
            return _responder.Response(input, _emotion.Mood);
        }


        // チョイスしたオブジェクトの名前を返すメソッド
        public string GetName()
        {
            return _responder.Name;
        }
    }
}
