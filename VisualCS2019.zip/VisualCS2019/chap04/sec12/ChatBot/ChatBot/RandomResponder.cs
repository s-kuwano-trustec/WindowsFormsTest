﻿using System;
using System.Collections.Generic;

namespace ChatBot
{
    class RandomResponder : Responder
    {
        public RandomResponder(string name, Cdictionary dic) : base(name, dic)
        {
            /* サブクラスのコンストラクター
             */
        }

        public override string Response(string input, int mood)
        {
            /* Response()メソッドをオーバーライド
             * 
             * ランダム辞書から応答メッセージを抽出して返す
             */

            // システム起動後のミリ秒単位の経過時間を取得
            int seed = Environment.TickCount;
            // シード値を引数にしてRandomをインスタンス化
            Random rdm = new Random(seed);

            // ランダム辞書を保持するリスト
            List<string> c_random = new List<string>();

            // VBDictionaryのRandomプロパティの応答メッセージをリストに代入
            c_random = this.Cdictionary.Random;

            // リストから応答メッセージをランダムに抽出して返す
            return c_random[rdm.Next(0, c_random.Count)];
        }

    }
}
