﻿using System.Collections.Generic;

namespace ChatBot
{
    class CchanEmotion
    {
        /*
         * C#ちゃんの感情モデル
         */

        // Cdictionaryにアクセスするプロパティ
        public Cdictionary Dictionary { get; set; }

        // 機嫌値にアクセスするプロパティ
        public int Mood { get; set; }

        // 機嫌値の上限/加減と回復値を設定
        private const int MOOD_MIN = -15;
        private const int MOOD_MAX = 15;
        private const int MOOD_RECOVERY = 1;

        public CchanEmotion(Cdictionary dictionary)
        {
            /*/ Dictionaryオブジェクトをdictionaryに格納し、
             * 機嫌値moodを0で初期化する
             *
             * dictionary： Dictionaryオブジェクト */
            this.Dictionary = dictionary;
            this.Mood = 0;
        }


        public void Update(string input)
        {
            /* ユーザーからの入力をパラメーターinputで受け取り
             *  パターン辞書にマッチさせて機嫌値を変動させる
             *
             * input： ユーザーの入力
             */

            // 機嫌を徐々にもとに戻す処理
            if (this.Mood < 0)
                Mood += MOOD_RECOVERY;
            else if (Mood > 0)
                Mood -= MOOD_RECOVERY;

            // パターン辞書の各行を繰り返しパターンマッチさせる
            foreach (ParseItem c_item in this.Dictionary.Pattern)
            {
                // パターンマッチすればAdjust_mood()で機嫌値を変動させる
                if (!string.IsNullOrEmpty(c_item.Match(input)))
                    Adjust_mood(c_item.Modify);
            }
        }


        public void Adjust_mood(int val)
        {
            /* 機嫌値を増減させる
            *
            * val： 機嫌変動値
            */

            // 機嫌値moodの値を機嫌変動値によって増減する
            Mood += val;
            // MOOD_MAXとMOOD_MINと比較し、機嫌値が取り得る範囲に収める
            if (Mood > MOOD_MAX)
                Mood = MOOD_MAX;
            else if (Mood < MOOD_MIN)
                Mood = MOOD_MIN;
        }
    }
}
