﻿using System;
using System.Windows.Forms;

namespace ChatBot
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Cchanクラスをインスタンス化
        private Cchan _chan = new Cchan("C#ちゃん");


        private void PutLog(string str)
        {
        /* 対話ログをテキストボックスに追加するメソッド
         *
         * str: 入力文字または応答メッセージ
         */
            textBox2.AppendText(str + "\r\n");
        }

        private string Prompt()
        {
        /* C#ちゃんのプロンプトを作るメソッド
         * 戻り値 プロンプト用の文字列
         */
            return _chan.Name + "：" + _chan.GetName() + "> ";
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            /* [話す]ボタンのイベントハンドラー
             * 
             */

            // テキストボックスに入力された文字列を取得
            string value = textBox1.Text;
            if (value == String.Empty)
            {
                // 未入力の場合の応答
                label1.Text = "なに？";
            }
            else
            {
                // 入力されていたら対話処理を実行
                // 入力文字列を引数にしてDialogue()の結果を取得
                string response = _chan.Dialogue(value);
                // 応答メッセージをラベルに表示
                label1.Text = response;
                // 入力文字列を引数にしてPutLog()を実行
                PutLog("> " + value);
                // 応答メッセージを引数にしてPutLog()を実行
                PutLog(Prompt() + response);
                // テキストボックスをクリア
                textBox1.Clear();

                // 現在の機嫌値を取得
                int em = _chan.Emotion.Mood;

                // 現在の機嫌値に応じて画像を取り換える
                if ((-5 <= em) && (em <= 5))
                {
                    this.pictureBox1.Image =
                        Properties.Resources.talk;  // 基本の表情
                }
                else if (-10 <= em & em < -5)
                    this.pictureBox1.Image = 
                        Properties.Resources.empty; // 虚ろな表情
                else if (-15 <= em & em < -10)
                    this.pictureBox1.Image =
                        Properties.Resources.angry; // 怒り心頭な表情
                else if (5 <= em & em < 15)
                    this.pictureBox1.Image =
                        Properties.Resources.happy; // ハッピーな表情

                // 現在の機嫌値をラベルに表示
                this.Label2.Text = Convert.ToString(_chan.Emotion.Mood);
            }
        }
    }
}
