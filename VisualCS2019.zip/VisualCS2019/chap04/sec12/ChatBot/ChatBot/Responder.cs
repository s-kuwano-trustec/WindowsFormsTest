﻿namespace ChatBot
{
    class Responder
    {
        /*
         * 応答クラスのスーパークラス
         * 
         */

        // オブジェクト名を参照/設定するプロパティ
        public string Name { get; set; }
        // Cdictionaryオブジェクトを参照/設定するプロパティ
        public Cdictionary Cdictionary { get; set; }

        public Responder(string name, Cdictionary dic)
       {
           /* コンストラクター
            * 
            */
           this.Name = name;        // 応答するオブジェクト名Nameにセット
            this.Cdictionary = dic; // CdictionaryオブジェクトをCdictionaryにセット
        }

         public virtual string Response(string input, int mood)
        {
           /* オーバーライドを前提にしたメソッド
            * インプット文字列を受け取り、応答メッセージを戻り値として返す
            */
           return "";
        }
    }
}
