﻿using System;

namespace ValueCopy
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            x = 100;

            int y;
            y = x;
            y = 10;

            Console.WriteLine(x);
            Console.WriteLine(y);

            Console.ReadKey();
        }
    }
}
