﻿using System;

namespace ReferenceType
{
    class Value
    {
        public int value;
    }

    class Program
    {
        static void Main(string[] args)
        {
            Value x;
            x = new Value();
            x.value = 1;

            Value y;
            y = new Value();
            y = x;
            y.value = 10;

            Console.WriteLine(x.value);
            Console.WriteLine(y.value);
            Console.ReadKey();
        }
    }
}
