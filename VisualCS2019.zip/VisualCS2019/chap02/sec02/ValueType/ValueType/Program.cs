﻿using System;

namespace ValueType
{
    class Program
    {
        static void Main(string[] args)
        {
            int x;
            x = 100;
            Console.WriteLine(x);
            Console.ReadKey();
        }
    }
}
