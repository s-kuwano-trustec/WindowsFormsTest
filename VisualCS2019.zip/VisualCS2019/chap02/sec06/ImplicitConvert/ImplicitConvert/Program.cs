﻿using System;

namespace ImplicitConvert
{
    class Program
    {
        static void Main(string[] args)
        {
            byte x = 5;
            byte y = 11;
            int total;

            total = x + y;
            Console.WriteLine(total);
            Console.ReadKey();
        }
    }
}
