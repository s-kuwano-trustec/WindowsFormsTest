﻿using System;

namespace UnBoxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int value1 = 100;
            object obj = (object)value1;
            int value2 = (int)obj;
            Console.WriteLine(value2);
            Console.ReadKey();
        }
    }
}
