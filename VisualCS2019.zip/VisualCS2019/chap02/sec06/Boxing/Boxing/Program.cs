﻿using System;

namespace Boxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int value = 100;
            object obj;
            obj = (object)value;
            Console.WriteLine(obj);
            Console.ReadKey();
        }
    }
}
