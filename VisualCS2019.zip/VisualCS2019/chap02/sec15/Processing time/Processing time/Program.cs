﻿using System;

namespace Processing_time
{
    struct S
    {
        public int num;
        public S(int n) { num = n; }
    }

    class C
    {
        public int num;
        public C(int n) { num = n; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            int s = 30000000;

            var now1 = DateTime.Now;
            S[] ar1 = new S[s];
            for (int i = 0; i < ar1.Length; i++) ar1[i] = new S(i);
            Console.WriteLine(DateTime.Now - now1);

            var now2 = DateTime.Now;
            C[] ar2 = new C[s];
            for (int i = 0; i < ar2.Length; i++) ar2[i] = new C(i);
            Console.WriteLine(DateTime.Now - now2);

            Console.ReadKey();
        }
    }
}
