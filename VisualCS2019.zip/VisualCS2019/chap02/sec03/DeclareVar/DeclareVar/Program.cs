﻿using System;

namespace DeclareVar
{
    class Program
    {
        static void Main(string[] args)
        {
            long a = 1;
            Console.WriteLine(a.GetType().Name);

            var b = 1;
            Console.WriteLine(b.GetType().Name);
            Console.ReadKey();
        }
    }
}
