﻿using System;

namespace Field
{
    class Test
    {
        public int x = 10;
    }

    class Program
    {
        static void Main(string[] args)
        {
            Test obj = new Test();
            int y = obj.x;
            Console.WriteLine(y);
            Console.ReadKey();
        }
    }
}
