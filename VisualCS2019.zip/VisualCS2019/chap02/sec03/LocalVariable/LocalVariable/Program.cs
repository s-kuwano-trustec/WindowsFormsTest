﻿using System;

namespace LocalVariable
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 1;
            Console.WriteLine(x);

            Test();
            Console.ReadKey();
        }

        static void Test()
        {
            int x = 20;
            Console.WriteLine(x);
        }

    }
}

