﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DictionaryApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var obj = new Dictionary<string, int>();
            obj.Add("element_1", 10);
            obj.Add("element_2", 20);
            obj.Add("element_3", 30);
            Disp(obj);
            Console.ReadKey();
        }

        static void Disp(Dictionary<string, int> t)
        {
            foreach (var item in t.Keys)
            {
                Console.WriteLine(
                    String.Format(
                        "{0}の値は{1}です。", item, t[item]));
            }
            Console.WriteLine("要素の値の合計は" + t.Values.Sum());
        }
    }
}
