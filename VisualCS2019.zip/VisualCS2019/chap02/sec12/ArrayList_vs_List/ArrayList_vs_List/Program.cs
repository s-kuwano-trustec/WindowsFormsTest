﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace ArrayList_vs_List
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime start, end;

            // ArrayListクラスを使う
            ArrayList arrayList = new ArrayList();
            start = DateTime.Now;
            for (int i = 0; i < 10000000; i++)
            {
                arrayList.Add(i);
            }
            end = DateTime.Now;

            Console.WriteLine(end - start);


            // Listジェネリッククラスを使う
            List<int> janericList = new List<int>();
            start = DateTime.Now;
            for (int i = 0; i < 10000000; i++)
            {
                janericList.Add(i);
            }
            end = DateTime.Now;

            Console.WriteLine(end - start);
            Console.ReadKey();
        }
    }
}
