﻿using System;
using System.Collections.Generic;

namespace GenericApp
{
    class Program
    {
        static void Main(string[] args)
        {            
            List<string> list = new List<string>();

            //Addメソッドによる要素の追加（List）
            list.Add("1番目のリスト");
            list.Add("2番目のリスト");

            string str1 = "3番目のリスト";
            list.Add(str1);

            //int x = 500;
            //stringList.Add(x); // コンパイルエラー

            foreach (string str in list)
            {
                Console.WriteLine(str);
            }
            Console.ReadKey();
        }
    }
}