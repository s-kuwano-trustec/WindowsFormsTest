﻿using System;
using System.Collections.Generic;

namespace ActionDelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj = new Class1();
            obj.DoDelegate();
            Console.ReadKey();
        }
    }

    class Class1
    {
        void Show(string str)
        {
            Console.WriteLine(str);
        }

        public void DoDelegate()
        {
            List<string> monthList = new List<string>();
            monthList.Add("January");
            monthList.Add("February");
            monthList.Add("March");
            monthList.Add("April");
            monthList.Add("May");

            // デリゲートインスタンスの作成
            Action<string> del = new Action<string>(Show);
            monthList.ForEach(del);
        }
    }
}