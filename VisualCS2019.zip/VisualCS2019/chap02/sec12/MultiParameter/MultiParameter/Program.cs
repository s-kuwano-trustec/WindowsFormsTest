﻿using System;

namespace MultiParameter
{
    class Test<T1, T2>
    {
        public T1 val1 { get; set; }
        public T2 val2 { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            var a = new Test<string, int>();
            var b = new Test<int, string>();
            a.val1 = "abc";
            a.val2 = 100;
            b.val1 = 500;
            b.val2 = "xyz";

            Console.WriteLine("a.val1={0}, a.val2={1}", a.val1, a.val2);
            Console.WriteLine("b.val1={0}, b.val2={1}", b.val1, b.val2);
            Console.ReadKey();
        }
    }
}
