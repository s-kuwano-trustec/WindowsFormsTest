﻿using System;

namespace GenericClass
{
    public class ListTest<T>
    {
        private T[] list = new T[100];
        int add;

        public void AddItem(T item)
        {
            list[add++] = item;
        }

        // インデクサーの定義
        public T this[int index]
        {
            get
            {
                return list[index];
            }

            set
            {
                list[index] = value;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            ListTest<string> list = new ListTest<string>();

            list.AddItem("1番目の要素です。");
            list.AddItem("2番目の要素です。");

            // 文字列の出力
            Console.WriteLine(list[0]);
            Console.WriteLine(list[1]);

            // DateTimeのリスト
            ListTest<DateTime> dt = new ListTest<DateTime>();

            dt.AddItem(DateTime.Today);

            // 日付の出力
            DateTime today = dt[0];
            Console.WriteLine(dt[0]);

            Console.ReadKey();
        }
    }
}
