﻿using System;

namespace GenericMethod
{
    class Program
    {
        static void Disp<T>(T p)
        {
            Console.WriteLine(p);
        }

        static void Main(string[] args)
        {
            Disp<int>(500);
            Disp<string>("VisualC#");

            Disp(500);
            Disp("VisualC#");

            Console.ReadKey();
        }
    }
}

