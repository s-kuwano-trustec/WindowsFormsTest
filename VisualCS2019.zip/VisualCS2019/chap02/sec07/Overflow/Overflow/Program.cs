﻿using System;

namespace Overflow
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 2147483647;
            x = x + 1;
            Console.WriteLine(x);
            Console.ReadKey();
        }
    }
}
