﻿using System;

namespace StringBuilder
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Text.StringBuilder str1 = new System.Text.StringBuilder();
            for (int i = 0; i < 50000; i++)
            {
                str1.Append("ABCDEFG");
            }
            Console.WriteLine("処理が終了しました。");
            Console.ReadKey();
        }
    }
}
