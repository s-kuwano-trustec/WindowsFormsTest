﻿using System;

namespace ImplicitlyCast
{
    class Program
    {
        static void Main(string[] args)
        {
            byte x, y;
            int z;
            x = 10;
            y = 20;
            z = x + y;
            Console.WriteLine(z);
            Console.ReadKey();
        }
    }
}
