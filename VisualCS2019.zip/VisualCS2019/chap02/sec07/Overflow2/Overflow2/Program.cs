﻿using System;

namespace Overflow2
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = -2147483648;
            x = x - 1;
            Console.WriteLine(x);
            Console.ReadKey();
        }
    }
}
