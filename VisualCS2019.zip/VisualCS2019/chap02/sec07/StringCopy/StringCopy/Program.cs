﻿using System;

namespace StringCopy
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "ABC";
            string str2 = str1;
            Console.WriteLine(str1);
            Console.WriteLine(str2);

            str1 = "DEF";
            Console.WriteLine("str1変更後のstr1の値" + str1);
            Console.WriteLine("str1変更後のstr2の値" + str2);
            Console.ReadKey();
        }
    }
}
