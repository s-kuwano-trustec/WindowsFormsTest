﻿using System;

namespace ConvertByte
{
    class Program
    {
        static void Main(string[] args)
        {
            byte x, y, z;
            x = 10;
            y = 20;
            z = Convert.ToByte(x + y);
            Console.WriteLine(z);
            Console.ReadKey();
        }
    }
}
