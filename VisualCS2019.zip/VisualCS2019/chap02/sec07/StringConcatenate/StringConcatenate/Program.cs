﻿using System;

namespace StringConcatenate
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "";
            for (int i = 0; i < 50000; i++)
            {
                str1 = str1 + "ABCDEFG";
            }
            Console.WriteLine("処理が終了しました。");
            Console.ReadKey();
        }
    }
}
