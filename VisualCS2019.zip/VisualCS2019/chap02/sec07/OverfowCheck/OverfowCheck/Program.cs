﻿using System;

namespace OverfowCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.MaxValue;
            int b = 1;
            checked
            {
                Console.WriteLine(a + b);
            }
        }
    }
}
