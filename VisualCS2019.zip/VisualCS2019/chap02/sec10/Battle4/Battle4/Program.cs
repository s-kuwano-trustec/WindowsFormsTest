﻿using System;

namespace Battle4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("まものたちがあらわれた！"); // 最初に出力

            Console.Write("お名前をどうぞ>>");    // ゲームの主人公名を取得
            string brave = Console.ReadLine();    // ユーザーの入力した文字列を1行読み込む

            string prompt = brave + "の呪文 > ";  // プロンプトを作る
            string attack = "";                   // 呪文を代入する変数を用意

            // 名前が入力されたら以下の処理を実行
            if (!string.IsNullOrEmpty(brave))
            {
                // attackが'ザラキン'でない限り繰り返す
                while (attack != "ザラキン")
                {
                    Console.Write(prompt);         //プロンプトを表示して 呪文を取得
                    attack = Console.ReadLine();
                    Console.WriteLine(brave + "は「" + attack + "」の呪文をとなえた！");
                    // attackが'ザラキン'でなければ以下を表示
                    if (attack != "ザラキン")
                    {
                        Console.WriteLine("まものたちは様子をうかがっている");
                    }
                }
                Console.WriteLine("まものたちは全滅した");
            }
            // 何も入力されなければゲームを終了
            else
            {
                Console.WriteLine("ゲーム終了");
            }
            Console.ReadKey();
        }
    }
}
