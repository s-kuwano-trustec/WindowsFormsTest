﻿using System;

namespace Battle2
{
    class Program
    {
        static void Main(string[] args)
        {
            // ゲームの主人公名を取得
            Console.Write("お名前をどうぞ>>");
            string brave = Console.ReadLine(); // ユーザーの入力した文字列を1行読み込む

            // 魔物の応答パターン
            string monster1 = "まものたちはひるんでいる";
            string monster2 = "まものたちはたいさんした";

            // 名前が入力されたら以下の処理を10回繰り返す
            if (!string.IsNullOrEmpty(brave))
            {
                // 10回繰り返す
                for (int i = 0; i < 10; i++)
                {
                    // 偶数回の処理なら勇者の攻撃を出力
                    if (i % 2 == 0)
                    {
                        Console.WriteLine(brave + "の攻撃！");
                    }
                    // 奇数回の処理なら魔物たちの応答mamono1を出力
                    else
                    {
                        Console.WriteLine(monster1);
                    }
                }
                Console.WriteLine(monster2);
            }
            // 何も入力されなければゲームを終了
            else
            {
                Console.WriteLine("ゲーム終了");
            }
            Console.ReadKey();
        }
    }
}

