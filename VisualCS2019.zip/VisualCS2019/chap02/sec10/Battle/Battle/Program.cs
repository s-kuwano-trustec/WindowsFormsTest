﻿using System;

namespace Battle
{
    class Program
    {
        static void Main(string[] args)
        {
            // ゲームの主人公名を取得
            Console.Write("お名前をどうぞ>>");
            string brave = Console.ReadLine(); // ユーザーの入力した文字列を1行読み込む

            // 名前が入力されたら以下の処理を実行
            if (!string.IsNullOrEmpty(brave))
            {
                for (int i = 0; i < 5; i++)
                {
                    Console.WriteLine(brave + "の攻撃！");

                }
                Console.WriteLine("まものたちはたいさんした");
            }

            // 何も入力されなければゲームを終了
            else
                Console.WriteLine("ゲーム終了");

            Console.ReadKey();
        }
    }
}
