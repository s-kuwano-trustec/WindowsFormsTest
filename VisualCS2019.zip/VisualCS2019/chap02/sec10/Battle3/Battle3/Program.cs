﻿using System;

namespace Battle3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("まものたちがあらわれた！");       // 最初に出力

            Console.Write("お名前をどうぞ>>");               // ゲームの主人公名を取得
            string brave = Console.ReadLine();

            string brave1 = brave + "のこうげき！";          // 1つ目の攻撃パターンを作る
            string brave2 = brave + "は呪文をとなえた！";    // 2つ目の攻撃パターンを作る
            string monster1 = "まものたちはひるんでいる";    // 魔物の反応その1
            string monster2 = "まものたちがはんげきした！";  // 魔物の反応その2
            string monster3 = "まものたちはたいさんした";    // 魔物の反応その2
            Random rnd = new Random();                       // Randomクラスのインスタンス化


            // 名前が入力されたら以下の処理を10回繰り返す
            if (!string.IsNullOrEmpty(brave))
            {
                // 繰り返しの前に勇者の攻撃を出力しておく
                Console.WriteLine(brave1);

                // 10回繰り返す
                for (int i = 0; i < 10; i++)
                {
                    // 1秒間スリープ
                    System.Threading.Thread.Sleep(1000);
                    // 0～9の範囲の値をランダムに生成
                    int num = rnd.Next(0, 10);
                    // 生成された値が2以下ならbrave1を出力
                    if (num <= 2)
                    {
                        Console.WriteLine(brave1);
                    }
                    // 生成された値が3以上5以下ならbrave2を出力
                    else if (num >= 3 & num <= 5)
                    {
                        Console.WriteLine(brave2);
                    }
                    // 生成された値が6以上8以下ならmonster1を出力
                    else if (num >= 6 & num <= 8)
                    {
                        Console.WriteLine(monster1);
                    }
                    // 上記以外はmonster2を出力
                    else
                    {
                        Console.WriteLine(monster2);
                    }
                }
                // forを抜けたらmonster3を出力
                Console.WriteLine(monster3);
            }
            // 何も入力されなければゲームを終了
            else
            {
                Console.WriteLine("ゲーム終了");
            }
            Console.ReadKey();
        }
    }
}
