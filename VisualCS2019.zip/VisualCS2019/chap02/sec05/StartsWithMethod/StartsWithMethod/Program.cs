﻿using System;

namespace StartsWithMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "Microsoft Visual C#";
            string str2 = "Microsoft";
            string str3 = "Visual C#";
            Console.WriteLine(str1.StartsWith(str2));
            Console.WriteLine(str1.StartsWith(str3));
            Console.ReadKey();
        }
    }
}
