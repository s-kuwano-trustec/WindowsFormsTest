﻿using System;

namespace Increment
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 1;
            int y = 1;
            Console.WriteLine(++x);        // ①前置インクリメント演算
            Console.WriteLine(y++);        // ②後置インクリメント演算
            Console.WriteLine("x＝" + x);  // インクリメント後のxの値
            Console.WriteLine("y＝" + y);  // インクリメント後のyの値
            Console.ReadKey();
        }
    }
}
