﻿using System;

namespace ContainsMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            string str1 = "Microsoft Visual C#";
            string str2 = "C#";
            string str3 = "C++";
            Console.WriteLine(str1.Contains(str2));
            Console.WriteLine(str1.Contains(str3));
            Console.ReadKey();
        }
    }
}
