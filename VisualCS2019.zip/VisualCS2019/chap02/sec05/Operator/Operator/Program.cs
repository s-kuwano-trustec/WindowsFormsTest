﻿using System;

namespace Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            bool b = true;
            b &= false;
            Console.WriteLine(b);
            Console.ReadKey();
        }
    }
}
