﻿using System;

namespace Decrement
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 1;
            int y = 1;
            Console.WriteLine(--x);        // ①前置デクリメント演算
            Console.WriteLine(y--);        // ②後置デクリメント演算
            Console.WriteLine("x＝" + x);  // デクリメントト後のxの値
            Console.WriteLine("y＝" + y);  // デクリメント後のyの値
            Console.ReadKey();
        }
    }
}
