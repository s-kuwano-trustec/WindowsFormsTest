﻿using System;

namespace Operator3
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 255;
            int shift = 4;
            num >>= shift;

            Console.WriteLine(num);
            Console.ReadKey();
        }
    }
}
