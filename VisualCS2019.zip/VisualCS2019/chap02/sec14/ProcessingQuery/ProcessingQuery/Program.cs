﻿using System;
using System.Linq;

namespace ProcessingQuery
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = { 100, 200, 300, 400, 500 };
            var r = from n in num
                    select n * 105 / 100;
            foreach (var n in r) Console.WriteLine(n);
            Console.ReadKey();
        }
    }
}
