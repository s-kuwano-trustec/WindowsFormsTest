﻿using System;
using System.Linq;

namespace OerderBy
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = { 50, 200, 15, 3, 75, 1000 };
            var r = from n in num
                    where n >= 10
                    orderby n
                    select n;
            foreach (var n in r) Console.WriteLine(n);
            Console.ReadKey();
        }
    }
}
