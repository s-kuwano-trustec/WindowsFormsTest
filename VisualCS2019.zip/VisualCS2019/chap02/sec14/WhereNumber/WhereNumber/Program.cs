﻿using System;
using System.Linq;

namespace WhereNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5 };
            var query = from n
                        in numbers
                        where n >= 2 && n <= 4
                        select n;
            foreach (var a in query) Console.WriteLine(a);

            Console.ReadKey();
        }
    }
}
