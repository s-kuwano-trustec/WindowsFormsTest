﻿using System;
using System.Linq;

namespace QueryUseMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] num = { 50, 200, 15, 3, 75, 1000 };
            var r = num.Where((n) => n >= 10).OrderBy((n) => n);
            foreach (var n in r) Console.WriteLine(n);
            Console.ReadKey();
        }
    }
}
