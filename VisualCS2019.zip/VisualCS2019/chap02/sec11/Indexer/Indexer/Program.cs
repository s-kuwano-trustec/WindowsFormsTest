﻿using System;

namespace Indexer
{
    class Test
    {
        public int[] testArray = new int[10] {10, 20, 30, 40, 50,
                                              60, 70, 80, 90, 100};
        // インデクサーの宣言
        public int this[int index]
        {
            get { return testArray[index]; }
            set { testArray[index] = value; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Test obj = new Test();

            obj[1] = 111;
            obj[2] = 555;
            obj.testArray[3] = 666;

            for (int i = 0; i < 10; i++)
            {
                System.Console.WriteLine("Element #{0} = {1}", i, obj[i]);
            }
            Console.ReadKey();
        }
    }
}
