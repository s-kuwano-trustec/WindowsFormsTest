﻿using System;
using System.Collections;

namespace ArrayListApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList col = new ArrayList();
            col.Add("VisualC#");
            col.Add(2019);
            Console.WriteLine(col[0]);
            Console.WriteLine(col[1]);
            Console.WriteLine(col[0].GetType().Name);
            Console.WriteLine(col[1].GetType().Name);
            Console.ReadKey();
        }
    }
}
