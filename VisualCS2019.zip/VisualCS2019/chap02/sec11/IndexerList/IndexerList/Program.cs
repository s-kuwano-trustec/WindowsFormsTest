﻿using System.Collections.Generic;

namespace IndexerList
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> obj =
                new List<int>() {
                    10, 20, 30, 40, 50,
                    60, 70, 80, 90, 100
                };

            obj[1] = 111;
            obj[2] = 555;

            for (int i = 0; i < 10; i++)
            {
                System.Console.WriteLine("Element #{0} = {1}", i, obj[i]);
            }

            System.Console.ReadKey();
        }
    }
}
