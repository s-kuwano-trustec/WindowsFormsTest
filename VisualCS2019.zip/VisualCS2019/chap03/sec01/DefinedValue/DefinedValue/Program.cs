﻿using System;

namespace DefinedValue
{
    class Program
    {
        static void test(int a = 1, int b = 2)
        {
            Console.WriteLine("a={0} b={1}", a, b);
        }
        static void Main(string[] args)
        {
            test();
            test(50);
            test(50, 100);
            Console.ReadKey();
        }
    }
}
