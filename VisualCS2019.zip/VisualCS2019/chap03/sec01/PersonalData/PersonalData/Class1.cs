﻿using System;

namespace PersonalData
{
    class Class1
    {
        private string name;
        private DateTime datBirthday;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public DateTime Birthday
        {
            get { return datBirthday; }
            set { datBirthday = value; }
        }

        public int GetAge()
        {
            int age = DateTime.Today.Year - datBirthday.Year;
            if (
                DateTime.Today.Month < datBirthday.Month ||
                DateTime.Today.Month == datBirthday.Month &&
                DateTime.Today.Day < datBirthday.Day
            )
            {
                age = age - 1;
            }
            return age;
        }
    }
}
