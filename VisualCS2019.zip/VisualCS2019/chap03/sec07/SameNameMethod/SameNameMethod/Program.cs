﻿using System;

namespace SameNameMethod
{
    interface ISample
    {
        void ShowA();
    }

    class SampleCls : ISample
    {
        void ISample.ShowA()
        {
            Console.WriteLine("インターフェイスのShowAメソッドです");
        }
        public void ShowA()
        {
            Console.WriteLine("SampleClsのShowAメソッドです");
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            SampleCls sc = new SampleCls();
            sc.ShowA();
            ISample isample = sc;
            isample.ShowA();
            Console.ReadKey();
        }
    }
}
