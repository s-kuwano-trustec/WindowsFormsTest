﻿using System;

namespace SuperClassType
{
    class Customer
    {
        public string name;
        public void registry(string name)
        {
            this.name = name;
        }
    }

    class Country : Customer
    {
        string country;
        void registry(string name, string country)
        {
            this.name = name;
            this.country = country;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Customer obj = new Country();
            obj.registry("Gerry Lopez");
            Console.WriteLine(obj.name);
            // obj.registry("Gerry Lopez", "米国");	// コンパイルエラーになる
            Console.ReadKey();
        }
    }
}
