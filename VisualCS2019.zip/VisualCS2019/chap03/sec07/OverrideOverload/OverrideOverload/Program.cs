﻿using System;

namespace OverrideOverload
{
    // 電源ボタンを扱う基本クラス
    class Button
    {
        // 電源ボタンを扱うメソッド
        public virtual void Push()
        {
            Console.WriteLine("電源スイッチが押されました。");
        }
    }

    // テレビのボタンを扱う派生クラス
    class TV : Button
    {
        // 電源ボタンを扱うオーバーライドメソッド
        public override void Push()
        {
            base.Push();
            Console.WriteLine("テレビの電源がオンです。");
        }

        // チャンネルボタンを扱うオーバーロードメソッド
        public void Push(int a)
        {
            Console.WriteLine(a + "チャンネルのボタンが押されました。");
            Console.WriteLine(a + "チャンネルを表示します。");
        }
    }

    // DVDプレイヤーのボタンを扱う派生クラス
    class DvdPlayer : Button
    {
        // 電源ボタンを扱うオーバーライドメソッド
        public override void Push()
        {
            base.Push();
            Console.WriteLine("スタンバイしています。");
        }

        // チャプター用のボタンを扱うオーバーロードメソッド
        public void Push(int a)
        {
            Console.WriteLine(a + "ボタンが押されました。");
            Console.WriteLine("チャプター" + a + "を再生します。");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            TV tv = new TV();	// TV型のインスタンスを生成
            Button bt = tv;		// 基本クラス型の参照変数に代入
            bt.Push();			// TVクラスのオーバーライドメソッドを実行
            tv.Push(6);			// TVクラスのオーバーロードメソッドを実行

            DvdPlayer dvd = new DvdPlayer();	// DVD_Player型のインスタンスを生成
            bt = dvd;			// 基本クラス型の参照変数に代入
            bt.Push();			// DvdPlayerクラスのオーバーライドメソッドを実行
            dvd.Push(10);		// DvdPlayerクラスのオーバーロードメソッドを実行}

            Console.ReadKey();
        }
    }
}
