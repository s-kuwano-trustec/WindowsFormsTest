﻿using System;

namespace Polymorphism
{
    class SuperClass
    {
        public virtual void disp()
        {
            Console.WriteLine("製品名は登録されていません。");
        }
    }

    class SubClass : SuperClass
    {
        public override void disp()
        {
            Console.WriteLine("製品名はPRODUCTSです");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            SuperClass obj = new SubClass();
            obj.disp();
            Console.ReadKey();
        }
    }
}

