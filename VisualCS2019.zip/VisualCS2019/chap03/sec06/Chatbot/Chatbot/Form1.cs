﻿using System;
using System.Windows.Forms;

namespace Chatbot
{
    public partial class Form1 : Form
    {
        // CSharpchanクラスをインスタンス化
        private CSharpchan _chan = new CSharpchan("C#ちゃん");


        public Form1()
        {
            InitializeComponent();
        }

        // 対話ログをテキストボックスに追加するメソッド
        // str 入力文字または応答メッセージ
        private void PutLog(string str)
        {
            textBox2.AppendText(str + "\r\n");
        }

        // C#ちゃんのプロンプトを作る関数
        // 戻り値 プロンプト用の文字列
        private string Prompt()
        {
            return _chan.Name + "：" + _chan.GetName() + "> ";

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            // テキストボックスに入力された文字列を取得
            string value = textBox1.Text;
            // 未入力の場合の応答
            if (string.IsNullOrEmpty(value))
            {
                label1.Text = "なに？";
            }
            // 入力されていたら対話処理を実行
            else
            {
                // 入力文字列を引数にしてDialogue()の結果を取得
                string response = _chan.Dialogue(value);
                // 応答メッセージをラベルに表示
                label1.Text = response;
                // 入力文字列を引数にしてPutLog()を実行
                PutLog("> " + value);
                // 応答メッセージを引数にしてPutLog()を実行
                PutLog(Prompt() + response);
                // テキストボックスをクリア
                textBox1.Clear();
            }
        }
    }
}
