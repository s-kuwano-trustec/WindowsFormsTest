﻿using System;

namespace Chatbot
{
    /*
    * オウム返しの応答を作るサブクラス
    *  
    */
    class RepeatResponder : Responder
    {
        // サブクラスのコンストラクター
        public RepeatResponder(string name) : base(name)
        {
        }

        // Response()メソッドをオーバーライド
        // オウム返しのメッセージを作成して返す
        public override string Response(string input)
        {
            return String.Format("{0}ってなに？", input);
        }
    }
}
