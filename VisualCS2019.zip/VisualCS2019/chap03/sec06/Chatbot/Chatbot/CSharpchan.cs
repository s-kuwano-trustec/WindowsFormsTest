﻿using System;

namespace Chatbot
{
    /*
     * C#ちゃんの本体クラス
     * 
     */
    class CSharpchan
    {
        private string name;                // オブジェクトの名前を保持するフィールド
        private RandomResponder res_random; // RandomResponderのインスタンスを保持する
        private RepeatResponder res_repeat; // RepeatResponderのインスタンスを保持する
        private Responder responder;        // Responder型のフィールド

        public string Name                  // nameフィールドにアクセスするためのプロパティ

        {
            get { return name; }
            set { name = value; }
        }

        // コンストラクター
        public CSharpchan(string name)
        {
            this.name = name;
            res_random = new RandomResponder("Random"); // RandomResponderをインスタンス化
            res_repeat = new RepeatResponder("Repeat"); // RepeatResponderをインスタンス化
        }

        // 応答メッセージを返すメソッド
        public string Dialogue(string input)
        {
            Random rnd = new Random();       // Randomのインスタンス化
            int num = rnd.Next(0, 10);       // 0～9の範囲の値をランダムに生成
            if (num < 6)                     // 0～5ならRandomResponderをチョイス
            {
                responder = res_random;
            }
            else                             // 6～9ならRepeatResponderをチョイス
            {
                responder = res_repeat;
            }
            // チョイスしたオブジェクトのResponse()メソッドを実行し
            // 応答メッセージを戻り値として返す
            return responder.Response(input);
        }

        // チョイスしたオブジェクトの名前を返すメソッド
        public string GetName()
        {
            return responder.Name;
        }
    }
}
