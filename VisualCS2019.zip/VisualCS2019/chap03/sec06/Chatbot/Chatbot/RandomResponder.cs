﻿using System;

namespace Chatbot
{
    /*
    * 独自の応答をランダムに返すサブクラス
    *  
    */
    class RandomResponder : Responder
    {
        // ランダム応答用の文字列
        private string[] responses = {
            "いい天気だね",
            "ぶっちゃけ、そういうことね",
            "10円ひろった",
            "じゃあこれ知ってる？",
            "それいいじゃない",
            "それかわいい♪"
        };

        // サブクラスのコンストラクター
        public RandomResponder(string name) : base(name)
        {
        }

        // Response()メソッドをオーバーライド
        // ランダム応答用のメッセージを作成して返す
        public override string Response(string input)
        {
            // Randomのインスタンス化
            Random rnd = new Random();
            // 配列からメッセージを抽出して戻り値として返す
            return responses[rnd.Next(0, responses.Length)];
        }
    }
}
