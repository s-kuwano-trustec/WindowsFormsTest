﻿using System;

namespace OverloadConstructor
{
    class SetNumber
    {
        public int numA;
        public int numB;
        public double numC;

        // パラメーターを3個持つコンストラクター①
        public SetNumber(int a, int b, double c)
        {
            numA = a;  // パラメーターで初期化
            numB = b;  // パラメーターで初期化
            numC = c;  // パラメーターで初期化
        }

        // int型のパラメーターを1個持つコンストラクター②
        public SetNumber(int a)
        {
            numA = a;     // パラメーターで初期化
            numB = 10;    // 規定値で初期化
            numC = 1.234; // 規定値で初期化
        }

        // double型のパラメーターを1個持つコンストラクター③
        public SetNumber(double c)
        {
            numA = 500; // 規定値で初期化
            numB = 10;  // 規定値で初期化
            numC = c;   // パラメーターで初期化
        }
    }

    class Program
    {

        static void Main(string[] args)
        {
            // コンストラクターの呼び出しに3個の引数を指定	→①を呼び出し
            SetNumber obj1 = new SetNumber(11, 22, 33.405);
            Console.WriteLine(
                obj1.numA + "," + obj1.numB + "," + obj1.numC
            );

            // コンストラクターの呼び出しにint型の引数1つを指定	→②を呼び出し
            SetNumber obj2 = new SetNumber(20);
            Console.WriteLine(
                obj2.numA + "," + obj2.numB + "," + obj2.numC
            );

            // コンストラクターの呼び出しにdouble型の引数1つを指定	→③を呼び出し
            SetNumber obj3 = new SetNumber(11.55);
            Console.WriteLine(
                obj3.numA + "," + obj3.numB + "," + obj3.numC
            );

            Console.ReadKey();
        }
    }
}
