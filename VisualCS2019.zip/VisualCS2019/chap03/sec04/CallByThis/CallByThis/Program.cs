﻿using System;

namespace CallByThis
{
    class Customer
    {
        public string id;
        public string name;
        public int age;

        // ①パラメーターを持たないコンストラクター
        public Customer()
            : this("-", "-", -1)    // ③のコンストラクターを呼び出す
        {

        }

        // ②idとnameをパラメーターに取るコンストラクター
        public Customer(string id, string name)
            : this(id, name, -1)    // ③のコンストラクターを呼び出す
        {

        }

        // ③id、name、ageをパラメーターに取るコンストラクター
        public Customer(string id, string name, int age)
        {
            this.id = id;
            this.name = name;
            this.age = age;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Customer obj1 = new Customer();                         // 引数なし
            Customer obj2 = new Customer("A101", "秀和太郎");       // 引数2つ
            Customer obj3 = new Customer("B101", "山田次郎", 28);   // 引数3つ

            Console.WriteLine(
                obj1.id + "," + obj1.name + "," + obj1.age  // obj1を出力
            );
            Console.WriteLine(
                obj2.id + "," + obj2.name + "," + obj2.age  // obj2を出力
            );
            Console.WriteLine(
                obj3.id + "," + obj3.name + "," + obj3.age  // obj3を出力
            );

            Console.ReadKey();
        }
    }
}
