﻿using System;

namespace NoNameArray
{
    class DataSet
    {
        public string s;
        public int[] n;	// 配列型のフィールド

        // 配列のパラメーターを持つコンストラクター
        public DataSet(String _s, int[] _n)
        {
            s = _s;
            n = _n;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // インスタンスの生成
            DataSet ds1 = new DataSet(
                "配列の値",
                new int[] { 10, 20, 30, 40, 50 }      // 無名配列
            );

            Console.Write(ds1.s + "= {");
            foreach (var m in ds1.n)                 // 配列要素を表示
            {
                Console.Write(m + " ");
            }
            Console.WriteLine("}");
            Console.ReadKey();
        }
    }
}
