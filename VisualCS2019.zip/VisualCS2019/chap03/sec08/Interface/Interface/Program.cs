﻿using System;

namespace Interface
{
    interface ISample
    {
        void Show();
    }

    class SampleCls : ISample  // SampleIF1を実装する
    {
        public void Show()
        {
            Console.WriteLine("SampleClsのShow()メソッドです");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            SampleCls sc = new SampleCls();
            sc.Show();

            Console.ReadKey();
        }
    }
}