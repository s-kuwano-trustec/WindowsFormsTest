﻿namespace ImplementInterface
{
    interface ISample
    {
        void DoCalc(int n);     // 計算処理を実行するための抽象メソッド
    }
}
