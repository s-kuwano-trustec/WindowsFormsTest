﻿using System;

namespace ImplementInterface
{
    abstract class SuperCls : ISample
    {
        public int Val { get; set; }        // 計算結果を保持するプロパティ
        public int Num { get; set; } = 100; // 計算に使用する値を保持するプロパティ

        // 掛け算を行うメソッド
        abstract public void Multiplier(int n);

        // 割り算を行うメソッド
        abstract public void Divider(int n);

        public void DoCalc(int n)
        {
            if (Num > n)
                //パラメーターnの値がNumより小さければMultiplier()を実行
                this.Multiplier(n);
            else
                //それ以外はDivider()を実行
                this.Divider(n);
        }
    }
}
