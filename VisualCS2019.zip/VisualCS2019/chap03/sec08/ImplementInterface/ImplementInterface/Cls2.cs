﻿using System.Windows.Forms;

namespace ImplementInterface
{
    class Cls2 : SuperCls  // SuperClsを継承
    {
        public override void Multiplier(int n)
        {
            Val = n * 4; // パラメーターの値を4倍する
            MessageBox.Show("処理結果は" + Val);
        }

        public override void Divider(int n)
        {
            Val = n / 4; // パラメーターの値を4で割る
            MessageBox.Show("処理結果は" + Val);
        }
    }
}