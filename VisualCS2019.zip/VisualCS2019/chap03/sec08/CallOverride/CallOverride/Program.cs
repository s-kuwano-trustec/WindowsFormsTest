﻿using System;

namespace CallOverride
{
    abstract class superClass
    {
         abstract public void disp();
    }

    class subClassA : superClass
    {
        public override void disp()
        {
            Console.WriteLine("商品名はPRODUCTです");
        }
    }

    class subClassB : superClass
    {
        public override void disp()
        {
            Console.WriteLine("商品名はMANUFACTUREです");
        }
    }

    class subClassC : superClass
    {
        public override void disp()
        {
            Console.WriteLine("商品名はGOODSです");
        }
    }


    class Program
    {
        static void Call(params superClass[] args)
        {
            foreach (superClass o in args)
            {
                o.disp(); // 派生クラスのdisp()メソッドを順番に呼び出す
            }
        }

        static void Main(string[] args)
        {
            superClass[] a = {
                new subClassA(), new subClassB(), new subClassC()
            };
            Call(a);

            Console.ReadKey();
        }
    }
}
