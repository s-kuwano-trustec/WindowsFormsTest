﻿using System;

namespace OverloadBySubClass
{
    class Customer
    {
        public string Name { get; set; }

        // パラメーターを1個持つメソッド
        public void Registry(string name)
        {
            Name = "君の名は" + name;
        }

        public void show1()
        {
            Console.WriteLine(Name);
        }
    }

    class Country : Customer
    {
        public string CountryName { get; set; }

        // パラメーターを2個持つオーバーロードしたメソッド
        public void Registry(string name, string country)
        {
            Name = "君の名は" + name;
            CountryName = "国籍は" + country;
        }

        public void show2()
        {
            Console.WriteLine(Name);
            Console.WriteLine(CountryName);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Country obj1 = new Country();
            obj1.Registry("秀和太郎");				// 引数は1個
            obj1.show1();

            Country obj2 = new Country();
            obj2.Registry("Gerry Lopez", "米国");	// 引数は2個
            obj2.show2();

            Console.ReadKey();
        }
    }
}
