﻿using System;

namespace InheritAndInherit
{
    class A
    {
        public A()
        {
            Console.WriteLine("Aクラスのコンストラクターです。");
        }
    }

    class B : A
    {
        public B()
        {
            Console.WriteLine("Bクラスのコンストラクターです。");
        }
    }

    class C : B
    {
        public C()
        {
            Console.WriteLine("Cクラスのコンストラクターです。");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            C obj = new C();
            Console.ReadKey();
        }
    }
}
