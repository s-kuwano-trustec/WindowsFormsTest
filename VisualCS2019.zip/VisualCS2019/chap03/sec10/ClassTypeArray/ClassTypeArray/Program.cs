﻿using System;

namespace ClassTypeArray
{
    public class TestClass
    {
        private string modifier;			// フィールド

        public TestClass(string modifier)	// コンストラクター
        {
            this.modifier = modifier;
        }

        public string Modifier
        {
            get { return modifier; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            TestClass[] a = new TestClass[3];	// 配列を作成
            a[0] = new TestClass("public");		// インスタンスの参照を要素に代入
            a[1] = new TestClass("private");
            a[2] = new TestClass("protected");

            foreach (TestClass tc in a)
            {
                // 画面表示
                Console.WriteLine(tc.Modifier);
            }
            Console.ReadKey();
        }
    }
}
