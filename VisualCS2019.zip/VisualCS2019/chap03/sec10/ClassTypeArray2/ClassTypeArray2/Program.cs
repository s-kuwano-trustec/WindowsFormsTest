﻿using System;

namespace ClassTypeArray2
{
    public class TestClass
    {
        private int id;
        private string product_name;

        public TestClass(int id, string product_name)
        {
            this.id = id;
            this.product_name = product_name;
        }

        public int Id
        {
            get { return id; }
        }

        public string Product_name
        {
            get { return product_name; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            TestClass[] a = { new TestClass(10001,"public"),
                              new TestClass(10002,"private"),
                              new TestClass(10003,"protected") };
            foreach (TestClass tc in a)
            {
                Console.WriteLine(tc.Id + "=" + tc.Product_name);
            }
            Console.ReadKey();
        }
    }
}
