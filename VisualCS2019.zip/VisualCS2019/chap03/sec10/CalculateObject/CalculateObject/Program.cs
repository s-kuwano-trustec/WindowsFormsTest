﻿using System;

namespace CalculateObject
{
    public class TestClass
    {
        private int num;
        public TestClass(int num)
        {
            this.num = num;
        }
        public int Num
        {
            get { return num; }
        }
        // 参照をパラメーターに取るメソッド
        public void Add(TestClass a)
        {
            // 呼び出し元と参照先のフィールドnumの値を合計する
            this.num += a.num;
        }

        public void Subtract(TestClass a)
        {
            // 呼び出し元のフィールドの値から
            // 参照先のフィールドの値を減算する
            this.num -= a.num;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            TestClass obj1 = new TestClass(400);	// インスタンスの生成
            TestClass obj2 = new TestClass(200);	// インスタンスの生成

            obj1.Add(obj2);							// 引数に参照変数を指定
            Console.WriteLine(obj1.Num);		    // 画面表示（getNum()が必要）

            obj1.Subtract(obj2);				 	// 引数に参照変数を指定
            Console.WriteLine(obj1.Num);		    // 画面表示（getNum()が必要）
            Console.ReadKey();
        }
    }
}
