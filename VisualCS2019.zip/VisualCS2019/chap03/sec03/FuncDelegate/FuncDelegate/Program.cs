﻿using System;
using System.IO;

namespace FuncDelegate
{
    public class Output
    {
        public bool SendToFile()
        {
            try
            {
                // 0バイトの一時ファイルをディスク上に作成し、ファイルのパスを取得
                string fn = Path.GetTempFileName();
                // 一時ファイル用のStreamWriterクラスのインスタンスを生成
                StreamWriter sw = new StreamWriter(fn);
                // TextWriter.WriteLineメソッド文字列と行終端記号を一時ファイルに書き込む
                sw.WriteLine("Hello, World!");
                // 書き込み用のストリームを閉じる
                sw.Close();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Output output = new Output();
            Func<bool> methodCall = output.SendToFile;
            if (methodCall())
                Console.WriteLine("一時ファイルへの書き込みが成功しました!");
            else
                Console.WriteLine("書き込みに失敗しました");
            Console.ReadKey();
        }
    }
}
