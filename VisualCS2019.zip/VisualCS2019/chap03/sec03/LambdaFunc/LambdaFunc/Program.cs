﻿using System;

namespace LambdaFunc
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 100;
            double d = 3.14159;
            Func<int, double, double> func = (x, y) => (x * y);

            double result = func(i, d);
            Console.WriteLine(result);
            Console.ReadKey();
        }
    }
}
