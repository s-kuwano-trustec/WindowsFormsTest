﻿using System;

namespace GenericMethod
{
    class Program
    {
        static void Test<T>(T t)
        {
            Console.WriteLine(t);
        }

        static void Main(string[] args)
        {
            Test(500);
            Console.ReadKey();
        }
    }
}
