﻿using System;

namespace ReferVariable1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 100;
            Func<int, int> func = (a) =>
            {
                return a * 2;
            };
            num = func(num);
            Console.WriteLine(num);
            Console.ReadKey();
        }
    }
}
