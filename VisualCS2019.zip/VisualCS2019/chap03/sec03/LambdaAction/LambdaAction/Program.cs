﻿using System;

namespace LambdaAction
{
    class Program
    {
        static void Main(string[] args)
        {
            Action<string> act = (x) =>
            {
                Console.WriteLine(x);
            };

            act("Hello world!");
            Console.ReadKey();
        }
    }
}
