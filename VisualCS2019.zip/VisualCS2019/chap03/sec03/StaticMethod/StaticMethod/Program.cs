﻿using System;

namespace StaticMethod
{
    class A
    {
        public static int Add(int p1, int p2)
        {
            return p1 + p2;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(A.Add(10, 10));
            Console.WriteLine(A.Add(100, 100));
            Console.ReadKey();
        }
    }
}
