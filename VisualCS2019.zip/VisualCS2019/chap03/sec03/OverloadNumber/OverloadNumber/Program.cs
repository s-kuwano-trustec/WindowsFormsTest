﻿using System;

namespace OverloadNumber
{
    class Member
    {
        // パラメーターを2個持つメソッド
        public void registry(string name, string country)
        {
            Console.WriteLine("名前は" + name + "：国籍は" + country);
        }

        // パラメーターを1個持つメソッド
        public void registry(string name)
        {
            Console.WriteLine("名前は" + name + "：国籍は日本");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Member obj1 = new Member();
            obj1.registry("Gerry Lopez", "米国");	// 引数は2個

            Member obj2 = new Member();
            obj2.registry("秀和太郎");				// 引数は1個
            Console.ReadKey();
        }
    }
}
