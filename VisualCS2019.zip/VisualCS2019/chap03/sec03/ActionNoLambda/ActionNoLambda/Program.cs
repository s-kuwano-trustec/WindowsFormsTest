﻿using System;

namespace ActionNoLambda
{
    class Program
    {
        static void Disp()
        {
            Console.WriteLine("Hello world!");
        }
        static void Main(string[] args)
        {
            Action act = Disp;
            act();
            Console.ReadKey();
        }
    }
}
