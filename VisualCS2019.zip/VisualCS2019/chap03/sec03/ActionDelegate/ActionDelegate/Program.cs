﻿using System;

namespace ActionDelegate
{
    class Program
    {
        static void Disp()
        {
            Console.WriteLine("Hello,world!");
        }

        static void a(Action call)
        {
            call();
        }

        static void Main(string[] args)
        {
            a(Disp);
            Console.ReadKey();
        }
    }
}
