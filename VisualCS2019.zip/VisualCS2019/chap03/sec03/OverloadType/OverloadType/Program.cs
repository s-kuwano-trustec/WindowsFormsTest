﻿using System;

namespace OverloadType
{
    class Judgment
    {
        int num;
        // コンストラクター
        public Judgment(int num) { this.num = num; }
        // int型のパラメーターを持つoverloadMethod()
        public bool overloadMethod(int val)
        { return num >= val; }
        // double型のパラメーターを持つoverloadMethod()
        public bool overloadMethod(double val)
        { return num >= val; }
    }
    class Program
    {

        static void Main(string[] args)
        {
            Judgment obj1 = new Judgment(100);
            // int型を引数にしてメソッドを実行
            bool return1 = obj1.overloadMethod(50);
            // double型を引数にしてメソッドを実行
            bool return2 = obj1.overloadMethod(150.55);
            Console.WriteLine(return1);
            Console.WriteLine(return2);

            Console.ReadKey();
        }
    }
}
