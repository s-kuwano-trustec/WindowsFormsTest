﻿using System;

namespace ReturnObject
{
    class Customer
    {
        public int Id;
        public string Name;
    }

    class Program
    {
        private static Customer getData()
        {
            return new Customer()
            {
                Id = 1001,
                Name = "Bill",
            };
        }

        static void Main(string[] args)
        {
            var dt = getData();
            Console.WriteLine("Name={0} Id={1}", dt.Name, dt.Id);
            Console.ReadKey();
        }
    }
}
