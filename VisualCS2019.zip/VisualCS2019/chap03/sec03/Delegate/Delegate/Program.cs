﻿using System;

namespace Delegate
{
    class Program
    {
        delegate void Del();
        static void Disp()
        {
            Console.WriteLine("Hello,world!");
        }

        static void a(Del call)
        {
            call();
        }

        static void Main(string[] args)
        {
            a(Disp);
            Console.ReadKey();
        }
    }
}
