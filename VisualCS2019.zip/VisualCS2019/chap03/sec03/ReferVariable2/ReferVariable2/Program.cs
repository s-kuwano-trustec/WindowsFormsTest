﻿using System;

namespace ReferVariable2
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 100;
            Action act = () =>
            {
                num *= 2;
            };
            act();
            Console.WriteLine(num);
            Console.ReadKey();
        }
    }
}
