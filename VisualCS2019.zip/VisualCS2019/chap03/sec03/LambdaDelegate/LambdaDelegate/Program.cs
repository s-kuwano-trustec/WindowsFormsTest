﻿using System;

namespace LambdaDelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            Action act = () =>
            {
                Console.WriteLine("Hello world!");
            };

            act();
            Console.ReadKey();
        }
    }
}
