﻿using System;

namespace PrivateMethod
{
    delegate void Del(string strMessage);

    class Class1
    {
        private void Show(string msg)
        {
            Console.WriteLine(msg);
        }

        public Del ReturnRef()
        {
            return new Del(this.Show);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj = new Class1();
            Del value = obj.ReturnRef();
            value("VisualC# 2019!");
            Console.ReadKey();
        }
    }
}