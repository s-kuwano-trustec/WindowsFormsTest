﻿using System;

namespace MulticastDelegate
{
    delegate void Del();

    class Class1
    {
        public void Show1()
        {
            Console.WriteLine("Show1()を実行");
        }

        public void Show2()
        {
            Console.WriteLine("Show2()を実行");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Class1 obj = new Class1();

            Del delObj1 = new Del(obj.Show1);
            Del delObj2 = new Del(obj.Show2);
            Del multi = delObj1 + delObj2;
            multi();
            Console.ReadKey();
        }
    }
}
