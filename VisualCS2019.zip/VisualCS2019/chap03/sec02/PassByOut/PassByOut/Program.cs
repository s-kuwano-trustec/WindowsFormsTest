﻿using System;

namespace PassByOut
{
    class Program
    {
        private static void getData(out string Name, out int Age)
        {
            Name = "Taro";
            Age = 26;
        }

        static void Main(string[] args)
        {
            string name;
            int age;
            getData(out name, out age);
            Console.WriteLine("Name={0} Age={1}", name, age);
            Console.ReadKey();
        }
    }
}
