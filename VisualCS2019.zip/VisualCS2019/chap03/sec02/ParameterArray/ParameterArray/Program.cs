﻿using System;

namespace ParameterArray
{
    class Program
    {
        static void Show(int n, params string[] s)
        {
            Console.WriteLine("グループ : " + n);
            foreach (var str in s) Console.WriteLine(str);
        }

        static void Main(string[] args)
        {
            Show(1, "レタス", "人参", "キャベツ", "玉ねぎ");
            Show(2, "白桃", "パパイヤ");
            string[] data = { "エリンギ", "マッシュルーム", "マイタケ" };
            Show(3, data);
            Console.ReadKey();
        }
    }
}
