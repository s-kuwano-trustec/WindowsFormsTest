﻿using System;

namespace ParameterName
{
    class Program
    {
        static void Proc(string s1, string s2, int num)
        {
            Console.WriteLine("a={0} b={1} c={2}", s1, s2, num);
        }

        static void Main(string[] args)
        {
            Proc(num: 2019, s2: "Visual Studio", s1: "Microsoft");
            Console.ReadKey();
        }
    }
}

