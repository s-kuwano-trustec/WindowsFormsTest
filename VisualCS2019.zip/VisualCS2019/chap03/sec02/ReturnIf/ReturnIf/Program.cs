﻿using System;

namespace ReturnIf
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] ar = { 10, 20, 30, 40, 50 };
            foreach (int i in ar)
            {
                if (i == 40) return;
                Console.WriteLine(i + "に到達しました。");
                Console.ReadKey();
            }            
        }
    }
}
