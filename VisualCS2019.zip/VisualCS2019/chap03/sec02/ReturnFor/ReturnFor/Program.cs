﻿using System;

namespace ReturnFor
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            for (; ; )
            {
                if (i > 100) return;
                Console.WriteLine("i = " + i);
                i = i * 2;
                Console.ReadKey();
            }            
        }
    }
}
