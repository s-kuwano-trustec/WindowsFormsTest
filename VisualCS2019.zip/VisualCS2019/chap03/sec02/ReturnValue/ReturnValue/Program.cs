﻿using System;

namespace ReturnValue
{
    class Program
    {
        static string Return()
        {
            return ("BYE-BYE");
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Mainメソッド実行中です。");
            string str = Return();
            Console.WriteLine(str);
            Console.ReadKey();
        }
    }
}
