﻿using System;

namespace PassByReference
{
    class Program
    {
        private static void getData(ref string Name, ref int Age)
        {
            Name = "Taro";
            Age = 26;
        }

        static void Main(string[] args)
        {
            string name = "";
            int age = 0;
            getData(ref name, ref age);
            Console.WriteLine("Name={0} Age={1}", name, age);
            Console.ReadKey();
        }
    }
}
